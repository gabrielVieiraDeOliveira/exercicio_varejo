class Vendedor {

    val nome: String? = null
    val turno: String? = null
    val comissao: Double? = null
    val 


}