
rootProject.name = "varejo"

